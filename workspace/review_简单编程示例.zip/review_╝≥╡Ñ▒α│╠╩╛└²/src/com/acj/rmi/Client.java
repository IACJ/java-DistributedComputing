package com.acj.rmi;

import java.rmi.Naming;

public class Client {
	public static void main(String[] args) {
		try{
			final int PORT = 1234;
			HelloInterface hello = (HelloInterface)Naming.lookup("rmi://localhost:"+PORT+"/hello");
			
			String message = hello.sayHello("ACJ");
			System.out.println(message);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
