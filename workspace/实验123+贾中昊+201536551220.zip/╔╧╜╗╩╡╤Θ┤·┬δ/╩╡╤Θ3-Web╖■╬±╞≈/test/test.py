
print("hello~ 我是一段python代码~ 而且我被执行了~~")

print("<br/>")
print("<br/>")

print("哈哈哈哈哈哈哈哈哈嗝")

