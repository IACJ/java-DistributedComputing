package com.acj.streamsocket;

public class Client {
	
	public static void main(String[] args) {
		try{
			final String HOST = "localhost";
			final int PORT = 1234;
			MyStreamSocket mySocket = new MyStreamSocket(HOST,PORT);
			
			mySocket.sendMessage("���~~");
			
			mySocket.close();
			
		}catch (Exception e){
			e.printStackTrace();
		}
	}

}
